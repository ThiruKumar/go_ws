Tests
======

This is just the start of a set of test scripts.  Consider everything here highly experimental.
