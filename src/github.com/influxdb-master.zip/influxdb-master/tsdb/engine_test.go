package tsdb_test

import _ "github.com/influxdb/influxdb/tsdb/engine"
